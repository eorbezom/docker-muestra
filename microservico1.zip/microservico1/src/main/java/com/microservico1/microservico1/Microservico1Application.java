package com.microservico1.microservico1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Microservico1Application {

	public static void main(String[] args) {
		SpringApplication.run(Microservico1Application.class, args);
	}

}
